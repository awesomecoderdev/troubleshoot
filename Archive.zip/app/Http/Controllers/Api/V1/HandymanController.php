<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreHandymanRequest;
use App\Http\Requests\UpdateHandymanRequest;
use App\Models\Handyman;

class HandymanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreHandymanRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Handyman $handyman)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Handyman $handyman)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateHandymanRequest $request, Handyman $handyman)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Handyman $handyman)
    {
        //
    }
}
